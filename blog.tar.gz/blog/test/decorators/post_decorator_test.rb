require 'test_helper'

class PostDecoratorTest < Draper::TestCase
end
