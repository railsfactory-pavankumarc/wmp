require 'test_helper'

class CommentDecoratorTest < Draper::TestCase
end
